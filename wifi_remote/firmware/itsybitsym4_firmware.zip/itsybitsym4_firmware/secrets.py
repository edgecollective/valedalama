secrets = {
    'ssid' : b'InmanSquareOasis',
    'password' : b'portauprince',
    'farmos_pubkey' : 'b0d28215311fc41b2cdfa6d1c09bba83',
    'farmos_privkey' : '2e65c9e07ff63e9548be632a864a4a52'
    }
